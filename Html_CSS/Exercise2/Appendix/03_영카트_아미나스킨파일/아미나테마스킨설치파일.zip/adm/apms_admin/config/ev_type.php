<?php
if (!defined('_GNUBOARD_')) exit;

// Event Type Set
$ev_type = array();

$ev_type[0] = '미지정';
$ev_type[1] = '일반상품전';
$ev_type[2] = '컨텐트상품전';

?>