<?php
// 쿠폰발행알림
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

@include($misc_skin_path.'/couponmail.mail.php');

?>