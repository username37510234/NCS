/*******************************************************************************
 *
 * apikey
 * Author: pupunzi
 * Creation date: 08/05/15
 * https://console.developers.google.com/
 ******************************************************************************/

jQuery.mbYTPlayer.apiKey = "AIzaSyB_z8WrsKw2kIplh5kBc6xTawEDu91V5dQ";
