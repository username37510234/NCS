<?php
// 회원가입 메일 (관리자 메일로 발송)
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

@include($misc_skin_path.'/register_form_update_mail2.php');

?>