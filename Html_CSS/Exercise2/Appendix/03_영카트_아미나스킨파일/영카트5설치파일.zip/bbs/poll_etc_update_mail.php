<?php
// 설문조사 기타의견 입력시 관리자께 보내는 메일을 수정하고 싶으시다면 이 파일을 수정하십시오. 
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가 

@include($misc_skin_path.'/poll_etc_update_mail.php');

?>