<?php
if (!defined('_GNUBOARD_')) exit;

include_once(ADMIN_SKIN_PATH.'/tail.php');
include_once(G5_PATH.'/tail.sub.php');
?>